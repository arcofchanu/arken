# ARKEN Paper Trading Extension

A browser extension for paper trading on Axiom with custom starting balance and PnL tracking.

## Features

- Paper trade on Axiom with a custom starting balance
- Real-time PnL tracking
- Custom overlay interface

## Installation (Developer Mode)

### For Chrome/Edge/Brave

1. **Clone or download this repository** to your local machine
   
2. **Open your browser's extensions page:**
   - Chrome: Navigate to `chrome://extensions/`
   - Edge: Navigate to `edge://extensions/`
   - Brave: Navigate to `brave://extensions/`

3. **Enable Developer Mode:**
   - Toggle the "Developer mode" switch in the top-right corner

4. **Load the extension:**
   - Click the "Load unpacked" button
   - Navigate to and select the `arkenExtension` folder
   - Click "Select Folder"

5. **Verify installation:**
   - The extension should now appear in your extensions list
   - You should see the ARKEN Paper Trading Extension with its icon

### For Firefox

1. **Clone or download this repository** to your local machine

2. **Open Firefox's debugging page:**
   - Navigate to `about:debugging#/runtime/this-firefox`

3. **Load the extension temporarily:**
   - Click "Load Temporary Add-on"
   - Navigate to the `arkenExtension` folder
   - Select the `manifest.json` file
   - Click "Open"

4. **Note:** In Firefox, temporary extensions are removed when you close the browser. You'll need to reload it each time you restart Firefox.

## Usage

1. Navigate to [axiom.trade](https://axiom.trade)
2. The extension will automatically activate on the Axiom trading platform
3. Use the overlay interface to manage your paper trading session


