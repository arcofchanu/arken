(function () {
  const STORAGE_KEY = "axiom_paper_state";

  const defaultState = {
    startingBalance: 0,
    balance: 0,
    pnl: 0,
    active: false
  };

  let state = { ...defaultState };

  function loadState() {
    chrome.storage.local.get([STORAGE_KEY], (res) => {
      if (res[STORAGE_KEY]) {
        state = res[STORAGE_KEY];
        updateUI();
      }
    });
  }

  function saveState() {
    chrome.storage.local.set({ [STORAGE_KEY]: state });
  }

  function resetState() {
    state = {
      startingBalance: state.startingBalance,
      balance: state.startingBalance,
      pnl: 0,
      active: true
    };
    saveState();
    updateUI();
  }

  function createUI() {
    if (document.getElementById("axiom-paper-panel")) return;

    const panel = document.createElement("div");
    panel.id = "axiom-paper-panel";

    panel.innerHTML = `
      <h3>PAPER MODE</h3>

      <div class="paper-section">
        <label>Starting Balance</label>
        <input id="paper-start-input" type="number" placeholder="10" />
        <button id="paper-start-btn" class="paper-btn">Start</button>
      </div>

      <div class="paper-section paper-stats">
        <div>Balance: <span id="paper-balance">0</span></div>
        <div>PnL: <span id="paper-pnl">0</span></div>
      </div>

      <div class="paper-section">
        <button id="paper-buy-btn" class="paper-btn paper-buy">Simulate Buy</button>
        <button id="paper-sell-btn" class="paper-btn paper-sell">Simulate Sell</button>
      </div>

      <div class="paper-section">
        <button id="paper-reset-btn" class="paper-btn paper-reset">Reset</button>
      </div>
    `;

    document.body.appendChild(panel);

    bindUI();
    updateUI();
  }

  function bindUI() {
    document.getElementById("paper-start-btn").onclick = () => {
      const val = parseFloat(
        document.getElementById("paper-start-input").value
      );
      if (isNaN(val) || val <= 0) return;

      state.startingBalance = val;
      state.balance = val;
      state.pnl = 0;
      state.active = true;
      saveState();
      updateUI();
    };

    document.getElementById("paper-reset-btn").onclick = () => {
      resetState();
    };

    document.getElementById("paper-buy-btn").onclick = () => {
      if (!state.active) return;
      simulateTrade(-1);
    };

    document.getElementById("paper-sell-btn").onclick = () => {
      if (!state.active) return;
      simulateTrade(1.2);
    };
  }

  function simulateTrade(delta) {
    state.balance += delta;
    state.pnl = state.balance - state.startingBalance;
    saveState();
    updateUI();
  }

  function updateUI() {
    const balanceEl = document.getElementById("paper-balance");
    const pnlEl = document.getElementById("paper-pnl");

    if (!balanceEl || !pnlEl) return;

    balanceEl.innerText = state.balance.toFixed(2);
    pnlEl.innerText = state.pnl.toFixed(2);

    pnlEl.style.color = state.pnl >= 0 ? "#00ff99" : "#ff4d4d";
  }

  createUI();
  loadState();

  const observer = new MutationObserver(() => {
    createUI();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
})();
