(function () {
  const STORAGE_KEY = "axiom_paper_state";

  const defaultState = {
    startingBalance: 0,
    balance: 0,
    pnl: 0,
    active: false,
    positions: [],
    trades: []
  };

  let state = { ...defaultState };
  let currentTokenPrice = 0;
  let currentTokenSymbol = "";
  let currentTokenAddress = "";
  let selectedBuyPercent = 100;
  let selectedSellPercent = 100;

  // Selectors to find Axiom UI elements (will be updated as we discover the DOM)
  const SELECTORS = {
    // Market cap elements - common patterns
    marketCap: [
      '[class*="market-cap"]',
      '[class*="marketCap"]',
      '[class*="MarketCap"]',
      '[class*="mcap"]',
      '[class*="Mcap"]',
      '[class*="market_cap"]',
      '[class*="mc-value"]',
      '[class*="mc_value"]',
      '[data-marketcap]',
      '[data-mcap]',
      '[data-market-cap]',
      // Axiom specific - try various patterns
      '[class*="stat"] [class*="value"]',
      '[class*="info"] [class*="value"]',
      '[class*="token"] [class*="stat"]',
      '[class*="metrics"]',
      '[class*="Metrics"]'
    ],
    // Price elements - common patterns (fallback)
    price: [
      '[class*="price"]',
      '[class*="Price"]',
      '[data-price]',
      '[class*="token-price"]',
      '[class*="current-price"]',
      '[class*="market-price"]'
    ],
    // Buy/Sell buttons
    buyButton: [
      'button[class*="buy"]',
      'button[class*="Buy"]',
      '[class*="buy-button"]',
      '[class*="buyButton"]',
      'button:has-text("Buy")'
    ],
    sellButton: [
      'button[class*="sell"]',
      'button[class*="Sell"]',
      '[class*="sell-button"]',
      '[class*="sellButton"]',
      'button:has-text("Sell")'
    ],
    // Token info
    tokenSymbol: [
      '[class*="symbol"]',
      '[class*="token-name"]',
      '[class*="tokenSymbol"]',
      'h1', 'h2', 'h3'
    ],
    // Amount input
    amountInput: [
      'input[type="number"]',
      'input[class*="amount"]',
      'input[class*="input"]',
      '[class*="amount-input"]'
    ]
  };

  function loadState() {
    chrome.storage.local.get([STORAGE_KEY], (res) => {
      if (res[STORAGE_KEY]) {
        state = { ...defaultState, ...res[STORAGE_KEY] };
        updateUI();
      }
    });
  }

  function saveState() {
    chrome.storage.local.set({ [STORAGE_KEY]: state });
  }

  function resetState() {
    state = {
      startingBalance: state.startingBalance,
      balance: state.startingBalance,
      pnl: 0,
      active: true,
      positions: [],
      trades: state.trades // Keep trade history on reset
    };
    saveState();
    updateUI();
  }

  // Find element using multiple selectors
  function findElement(selectorArray) {
    for (const selector of selectorArray) {
      try {
        const el = document.querySelector(selector);
        if (el) return el;
      } catch (e) {
        // Invalid selector, skip
      }
    }
    return null;
  }

  // Find all elements matching any selector
  function findAllElements(selectorArray) {
    const results = [];
    for (const selector of selectorArray) {
      try {
        const els = document.querySelectorAll(selector);
        els.forEach(el => {
          if (!results.includes(el)) results.push(el);
        });
      } catch (e) {
        // Invalid selector, skip
      }
    }
    return results;
  }

  // Format market cap for display
  function formatMarketCap(mcap) {
    if (mcap >= 1e9) return `$${(mcap / 1e9).toFixed(2)}B`;
    if (mcap >= 1e6) return `$${(mcap / 1e6).toFixed(2)}M`;
    if (mcap >= 1e3) return `$${(mcap / 1e3).toFixed(2)}K`;
    return `$${mcap.toFixed(2)}`;
  }

  // Parse market cap value from text (handles K, M, B suffixes)
  function parseMarketCapValue(text) {
    const cleanText = text.replace(/[^\d.KMBkmb]/g, '').toUpperCase();
    const match = cleanText.match(/([\d.]+)([KMB]?)/);
    if (!match) return 0;
    
    let value = parseFloat(match[1]);
    const suffix = match[2];
    
    if (suffix === 'K') value *= 1e3;
    else if (suffix === 'M') value *= 1e6;
    else if (suffix === 'B') value *= 1e9;
    
    return value;
  }

  // Cache for MC element to speed up detection
  let cachedMCElement = null;
  let lastMCValue = 0;
  let lastTokenAddress = null;
  let lastUrl = window.location.href;
  let tokenJustChanged = false;
  let tokenChangeTime = 0;
  const TOKEN_CHANGE_DELAY = 2000; // 2 second delay after token switch

  // Clear cache when token changes
  function checkTokenChange() {
    const currentUrl = window.location.href;
    const urlMatch = window.location.pathname.match(/\/(meme|trade|token)\/([A-Za-z0-9]+)/);
    const newAddress = urlMatch ? urlMatch[2] : null;
    
    // Check if URL changed OR token address changed
    if (currentUrl !== lastUrl || (newAddress && newAddress !== lastTokenAddress)) {
      // Token/page changed - clear cache completely
      cachedMCElement = null;
      lastMCValue = 0;
      lastUrl = currentUrl;
      tokenJustChanged = true;
      tokenChangeTime = Date.now();
      if (newAddress) {
        lastTokenAddress = newAddress;
      }
      console.log('[Axiom Paper] Token/page changed, cache cleared. New address:', newAddress);
      return true;
    }
    return false;
  }

  // Check if we're still in the delay period after token change
  function isInTokenChangeDelay() {
    if (!tokenJustChanged) return false;
    const elapsed = Date.now() - tokenChangeTime;
    if (elapsed >= TOKEN_CHANGE_DELAY) {
      // Delay period over, reset flag
      tokenJustChanged = false;
      return false;
    }
    return true;
  }

  // Force clear MC cache (can be called externally)
  function clearMCCache() {
    cachedMCElement = null;
    lastMCValue = 0;
    tokenJustChanged = true;
    tokenChangeTime = Date.now();
    console.log('[Axiom Paper] MC cache manually cleared');
  }

  // Extract market cap from DOM
  function extractMarketCap() {
    // Check if token changed, if so clear cache
    const changed = checkTokenChange();
    
    // Check if we're on a token page at all
    const urlMatch = window.location.pathname.match(/\/(meme|trade|token)\/([A-Za-z0-9]+)/);
    if (!urlMatch) {
      // Not on a token page - clear everything and return 0
      cachedMCElement = null;
      lastMCValue = 0;
      return 0;
    }
    
    // If still in delay period after token change, return 0 and wait
    if (isInTokenChangeDelay()) {
      console.log('[Axiom Paper] Waiting for new token to load...', Math.ceil((TOKEN_CHANGE_DELAY - (Date.now() - tokenChangeTime)) / 1000), 's');
      return 0;
    }
    
    // First check if user has set manual MC
    const manualMC = document.getElementById('paper-manual-mc');
    if (manualMC && manualMC.value) {
      const val = parseMarketCapValue(manualMC.value);
      if (val > 0) return val;
    }

    // Try cached element first for speed
    if (cachedMCElement && document.contains(cachedMCElement)) {
      const text = cachedMCElement.textContent || cachedMCElement.innerText || '';
      const mcap = parseMarketCapValue(text);
      if (mcap > 0) {
        lastMCValue = mcap;
        return mcap;
      }
    }

    // Force fresh search - clear old cached element
    cachedMCElement = null;

    // Try to find market cap elements first
    const mcapElements = findAllElements(SELECTORS.marketCap);
    
    for (const el of mcapElements) {
      const text = el.textContent || el.innerText || '';
      const mcap = parseMarketCapValue(text);
      if (mcap > 0) {
        cachedMCElement = el; // Cache this element
        lastMCValue = mcap;
        console.log('[Axiom Paper] Found MC via selector:', mcap, text);
        return mcap;
      }
    }

    // Quick scan for common MC patterns (faster than TreeWalker)
    const mcPatterns = [
      /MC[:\s]*\$?([\d,.]+)\s*([KMBkmb])/gi,
      /Market\s*Cap[:\s]*\$?([\d,.]+)\s*([KMBkmb])?/gi,
      /MCAP[:\s]*\$?([\d,.]+)\s*([KMBkmb])?/gi,
      /\$([\d,.]+)\s*([KMBkmb])\s*MC/gi
    ];

    const bodyText = document.body.innerText || '';
    for (const pattern of mcPatterns) {
      pattern.lastIndex = 0; // Reset regex
      const match = pattern.exec(bodyText);
      if (match) {
        let value = parseFloat(match[1].replace(/,/g, ''));
        const suffix = (match[2] || '').toUpperCase();
        if (suffix === 'K') value *= 1e3;
        else if (suffix === 'M') value *= 1e6;
        else if (suffix === 'B') value *= 1e9;
        
        if (value >= 1000) {
          lastMCValue = value;
          console.log('[Axiom Paper] Found MC via quick scan:', value);
          return value;
        }
      }
    }

    // Search for specific elements with MC text (slower, last resort)
    const smallElements = document.querySelectorAll('span, div, p, td, li');
    for (const el of smallElements) {
      if (el.children.length > 3) continue; // Skip containers
      const text = el.textContent || '';
      if (text.length < 3 || text.length > 50) continue;
      
      // Look for patterns like "MC $1.5M" or "MC: 1.5M" or "1.5M MC"
      const patterns = [
        /MC[:\s]*\$?([\d,.]+)\s*([KMBkmb])/i,
        /\$?([\d,.]+)\s*([KMBkmb])\s*MC/i
      ];
      
      for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match) {
          let value = parseFloat(match[1].replace(/,/g, ''));
          const suffix = (match[2] || '').toUpperCase();
          if (suffix === 'K') value *= 1e3;
          else if (suffix === 'M') value *= 1e6;
          else if (suffix === 'B') value *= 1e9;
          
          if (value >= 1000) {
            cachedMCElement = el; // Cache for next time
            lastMCValue = value;
            console.log('[Axiom Paper] Found MC via element scan:', value, text);
            return value;
          }
        }
      }
    }

    console.log('[Axiom Paper] Could not detect MC');
    // Only return cached value if it was found recently (within 10 seconds)
    // Otherwise return 0 to avoid showing stale/wrong MC
    return 0;
  }

  // Extract price from DOM (kept as fallback/reference)
  function extractPrice() {
    // Try to find price in the page
    const priceElements = findAllElements(SELECTORS.price);
    
    for (const el of priceElements) {
      const text = el.textContent || el.innerText || '';
      // Match price patterns like $0.00001234 or 0.00001234
      const match = text.match(/\$?([\d,]+\.?\d*)/);
      if (match) {
        const price = parseFloat(match[1].replace(/,/g, ''));
        if (price > 0 && price < 1000000) { // Reasonable price range
          return price;
        }
      }
    }

    // Also check for data attributes
    const allElements = document.querySelectorAll('[data-price], [data-value]');
    for (const el of allElements) {
      const price = parseFloat(el.dataset.price || el.dataset.value);
      if (price > 0) return price;
    }

    return 0;
  }

  // Extract token symbol from URL or DOM
  function extractTokenInfo() {
    // Try URL first (Axiom uses /meme/ADDRESS or /trade/ADDRESS patterns)
    const urlMatch = window.location.pathname.match(/\/(meme|trade|token)\/([A-Za-z0-9]+)/);
    if (urlMatch) {
      currentTokenAddress = urlMatch[2];
    } else {
      // Not on a token page - clear token info
      currentTokenAddress = '';
      currentTokenSymbol = '';
      return { symbol: '', address: '' };
    }

    // Try to find symbol in DOM
    const symbolElements = findAllElements(SELECTORS.tokenSymbol);
    for (const el of symbolElements) {
      const text = (el.textContent || '').trim();
      // Match token symbols (usually 2-10 uppercase letters)
      if (text.match(/^[A-Z]{2,10}$/) || text.match(/^\$[A-Z]{2,10}$/)) {
        currentTokenSymbol = text.replace('$', '');
        break;
      }
    }

    return { symbol: currentTokenSymbol, address: currentTokenAddress };
  }

  // Hook into Axiom's buy/sell buttons
  function hookTradingButtons() {
    // Find and hook buy buttons
    const buyButtons = findAllElements(SELECTORS.buyButton);
    buyButtons.forEach(btn => {
      if (btn.dataset.axiomPaperHooked) return;
      btn.dataset.axiomPaperHooked = 'true';
      
      btn.addEventListener('click', (e) => {
        if (!state.active) return;
        
        const price = extractPrice();
        const tokenInfo = extractTokenInfo();
        const amount = getInputAmount();
        
        if (price > 0 && amount > 0) {
          executePaperBuy(price, amount, tokenInfo);
        }
      }, true);
    });

    // Find and hook sell buttons
    const sellButtons = findAllElements(SELECTORS.sellButton);
    sellButtons.forEach(btn => {
      if (btn.dataset.axiomPaperHooked) return;
      btn.dataset.axiomPaperHooked = 'true';
      
      btn.addEventListener('click', (e) => {
        if (!state.active) return;
        
        const price = extractPrice();
        const tokenInfo = extractTokenInfo();
        const amount = getInputAmount();
        
        if (price > 0 && amount > 0) {
          executePaperSell(price, amount, tokenInfo);
        }
      }, true);
    });
  }

  // Get amount from input field
  function getInputAmount() {
    const inputs = findAllElements(SELECTORS.amountInput);
    for (const input of inputs) {
      const val = parseFloat(input.value);
      if (val > 0) return val;
    }
    return 1; // Default to 1 if no input found
  }

  function executePaperBuy(solAmount, tokenInfo, marketCap) {
    if (solAmount > state.balance) {
      showNotification('Insufficient paper balance!', 'error');
      return;
    }

    state.balance -= solAmount;
    
    // Add to positions - we track the entry market cap and SOL invested
    const existingPos = state.positions.find(p => p.address === tokenInfo.address);
    if (existingPos) {
      // Average the entry market cap weighted by SOL invested
      const totalInvested = existingPos.investedSol + solAmount;
      existingPos.entryMarketCap = ((existingPos.entryMarketCap * existingPos.investedSol) + (marketCap * solAmount)) / totalInvested;
      existingPos.investedSol = totalInvested;
    } else {
      state.positions.push({
        symbol: tokenInfo.symbol || 'UNKNOWN',
        address: tokenInfo.address,
        investedSol: solAmount,
        entryMarketCap: marketCap,
        entryTime: Date.now()
      });
    }

    // Log trade
    state.trades.push({
      type: 'BUY',
      symbol: tokenInfo.symbol,
      marketCap: marketCap,
      solAmount: solAmount,
      time: Date.now()
    });

    saveState();
    updateUI();
    showNotification(`Paper BUY: ${solAmount.toFixed(4)} SOL @ MC ${formatMarketCap(marketCap)}`, 'buy');
  }

  function executePaperSell(sellPercent, tokenInfo, currentMarketCap) {
    const existingPos = state.positions.find(p => p.address === tokenInfo.address);
    
    if (!existingPos || existingPos.investedSol <= 0) {
      showNotification('Insufficient paper position!', 'error');
      return;
    }

    // Calculate current value based on market cap change
    const mcapMultiplier = currentMarketCap / existingPos.entryMarketCap;
    const currentValue = existingPos.investedSol * mcapMultiplier;
    
    // Sell portion
    const solToSell = (existingPos.investedSol * sellPercent) / 100;
    const proceeds = (currentValue * sellPercent) / 100;
    
    state.balance += proceeds;
    existingPos.investedSol -= solToSell;

    if (existingPos.investedSol <= 0.0001) {
      state.positions = state.positions.filter(p => p.address !== tokenInfo.address);
    }

    // Log trade
    state.trades.push({
      type: 'SELL',
      symbol: tokenInfo.symbol,
      marketCap: currentMarketCap,
      proceeds: proceeds,
      pnlPercent: ((mcapMultiplier - 1) * 100).toFixed(2),
      time: Date.now()
    });

    saveState();
    updateUI();
    const pnlPercent = ((mcapMultiplier - 1) * 100).toFixed(1);
    const pnlSign = mcapMultiplier >= 1 ? '+' : '';
    showNotification(`Paper SELL: ${proceeds.toFixed(4)} SOL (${pnlSign}${pnlPercent}%)`, 'sell');
  }

  function showNotification(message, type) {
    const notif = document.createElement('div');
    notif.className = 'axiom-paper-notification';
    notif.classList.add(`notif-${type}`);
    notif.textContent = message;
    document.body.appendChild(notif);
    
    setTimeout(() => notif.remove(), 3000);
  }

  function createUI() {
    if (document.getElementById("axiom-paper-panel")) return;

    // Add local Poppins font from extension assets
    const fontUrl = chrome.runtime.getURL('assets/Poppins-Regular.ttf');
    const fontStyle = document.createElement('style');
    fontStyle.textContent = `
      @font-face {
        font-family: 'Poppins';
        src: url('${fontUrl}') format('truetype');
        font-weight: 400;
        font-style: normal;
      }
    `;
    document.head.appendChild(fontStyle);

    // Add notification styles
    const style = document.createElement('style');
    style.textContent = `
      #axiom-paper-panel, #axiom-paper-panel * {
        font-family: 'Poppins', sans-serif;
      }
      .axiom-paper-notification {
        position: fixed;
        top: 80px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 8px;
        font-family: 'Poppins', sans-serif;
        font-size: 13px;
        z-index: 1000000;
        animation: slideIn 0.3s ease;
      }
      .notif-buy { background: #0f5132; color: #fff; }
      .notif-sell { background: #842029; color: #fff; }
      .notif-error { background: #dc3545; color: #fff; }
      @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      .paper-positions { 
        max-height: 120px; 
        overflow-y: auto; 
        font-size: 11px;
        margin-top: 8px;
      }
      .paper-position-item {
        display: flex;
        justify-content: space-between;
        padding: 4px 0;
        border-bottom: 1px solid #333;
      }
      .paper-trades {
        max-height: 180px;
        overflow-y: auto;
        font-size: 11px;
        margin-top: 8px;
        background: rgba(0,0,0,0.3);
        border-radius: 6px;
        padding: 6px;
      }
      .paper-trade-item {
        padding: 8px 6px;
        border-bottom: 1px solid #333;
        background: rgba(255,255,255,0.02);
        border-radius: 4px;
        margin-bottom: 4px;
      }
      .paper-trade-item:last-child {
        border-bottom: none;
        margin-bottom: 0;
      }
      .paper-trade-buy-label {
        color: #00ff99;
        font-weight: bold;
      }
      .paper-trade-sell-label {
        color: #ff4d4d;
        font-weight: bold;
      }
      .paper-trade-details {
        color: #888;
        font-size: 9px;
        margin-top: 2px;
      }
      .paper-mc-badge {
        display: inline-block;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 9px;
        margin-left: 4px;
      }
      .paper-mc-entry {
        background: #1a3d1a;
        color: #00ff99;
      }
      .paper-mc-exit {
        background: #3d1a1a;
        color: #ff4d4d;
      }
      .paper-live-price {
        font-size: 11px;
        color: #888;
        margin-top: 4px;
      }
      .paper-percent-btns {
        display: flex;
        gap: 4px;
        margin-top: 6px;
      }
      .paper-percent-btn {
        flex: 1;
        padding: 4px;
        font-size: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        background: #333;
        color: #fff;
        transition: background 0.2s;
      }
      .paper-percent-btn:hover {
        background: #444;
      }
      .paper-percent-btn.active {
        background: #00ffd1;
        color: #000;
      }
      .paper-trade-btns {
        display: flex;
        gap: 8px;
        margin-top: 8px;
      }
      .paper-trade-btn {
        flex: 1;
        padding: 12px 8px;
        font-size: 14px;
        font-weight: bold;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: opacity 0.2s, transform 0.1s;
      }
      .paper-trade-btn:hover {
        opacity: 0.9;
        transform: scale(1.02);
      }
      .paper-trade-btn:active {
        transform: scale(0.98);
      }
      .paper-trade-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
        transform: none;
      }
      .paper-trade-buy {
        background: linear-gradient(135deg, #00c853, #00a844);
        color: #fff;
      }
      .paper-trade-sell {
        background: linear-gradient(135deg, #ff4444, #cc0000);
        color: #fff;
      }
      .paper-amount-row {
        display: flex;
        justify-content: space-between;
        font-size: 11px;
        color: #aaa;
        margin-top: 6px;
        margin-bottom: 4px;
      }
      #axiom-paper-panel {
        cursor: default;
      }
      .paper-drag-handle {
        cursor: move;
        padding: 8px 0;
        margin: -14px -14px 10px -14px;
        padding: 10px 14px;
        background: linear-gradient(135deg, #000000ff 0%rgba(0, 0, 0, 1)3e 100%);
        border-radius: 12px 12px 0 0;
        border-bottom: 1px solid rgba(0, 255, 209, 0.2);
        user-select: none;
      }
      .paper-drag-handle:hover {
        background: linear-gradient(135deg, #1f1f3a 0%, #1a2744 100%);
      }
      .paper-drag-handle h3 {
        margin: 0;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .paper-drag-handle h3 * {
        pointer-events: none;
      }
      .paper-header-icon {
        width: 18px;
        height: 18px;
        vertical-align: middle;
      }
      .paper-toggle-container {
        position: absolute;
        top: 10px;
        right: 12px;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .paper-toggle-label {
        font-size: 10px;
        color: #888;
        text-transform: uppercase;
      }
      .paper-toggle {
        position: relative;
        width: 36px;
        height: 18px;
        background: #333;
        border-radius: 9px;
        cursor: pointer;
        transition: background 0.3s;
      }
      .paper-toggle.active {
        background: #00c853;
      }
      .paper-toggle::after {
        content: '';
        position: absolute;
        top: 2px;
        left: 2px;
        width: 14px;
        height: 14px;
        background: #fff;
        border-radius: 50%;
        transition: transform 0.3s;
      }
      .paper-toggle.active::after {
        transform: translateX(18px);
      }
      #axiom-paper-panel.minimized .paper-content {
        display: none;
      }
      #axiom-paper-panel.minimized {
        width: auto;
        min-width: 140px;
      }
      #axiom-paper-panel.minimized .paper-drag-handle {
        border-radius: 12px;
        border-bottom: none;
        margin-bottom: 0;
      }
      #axiom-paper-panel.minimized .paper-toggle-container {
        position: static;
        justify-content: center;
        margin-top: 8px;
      }
      #axiom-paper-panel.minimized .paper-drag-handle h3 {
        margin-bottom: 0;
      }
    `;
    document.head.appendChild(style);

    const panel = document.createElement("div");
    panel.id = "axiom-paper-panel";

    const logoUrl = chrome.runtime.getURL('assets/ARKEN.png');
    const watermarkUrl = chrome.runtime.getURL('assets/WM.png');
    
    panel.innerHTML = `
      <img src="${watermarkUrl}" class="paper-watermark" alt="" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); opacity: 0.32; pointer-events: none; z-index: 0; max-width: 100%; max-height: 100%;">
      <div class="paper-drag-handle" id="paper-drag-handle" style="position: relative; z-index: 1;">
        <h3><img src="${logoUrl}" class="paper-header-logo" alt="ARKEN" style="height: 40px; vertical-align: middle;"></h3>
        <div class="paper-toggle-container">
          <div class="paper-toggle active" id="paper-toggle"></div>
        </div>
      </div>
      <div class="paper-content" style="position: relative; z-index: 1;">
        <div class="paper-live-price">
          Live MC: <span id="paper-live-mcap">--</span>
          <span id="paper-mc-status" style="font-size: 10px;"></span>
          <br>Token: <span id="paper-live-token">--</span>
          <br><span id="paper-live-address" style="font-size: 9px; color: #888; word-break: break-all; cursor: pointer;" title="Click to copy">--</span>
        </div>
        
        <div class="paper-section" style="margin-top: 8px;">
          <label>Manual MC (if auto fails)</label>
          <input id="paper-manual-mc" type="text" placeholder="e.g. 1.5M or 500K" style="width: 100%; margin-top: 4px; padding: 6px; border-radius: 6px; border: none;" />
        </div>

      <div class="paper-section">
        <label>Starting Balance (SOL)</label>
        <input id="paper-start-input" type="number" placeholder="10" />
        <button id="paper-start-btn" class="paper-btn">Start</button>
      </div>

      <div class="paper-section paper-stats">
        <div>Cash: <span id="paper-balance">0</span> SOL</div>
        <div>Positions: <span id="paper-positions-value">0</span> SOL</div>
      </div>
      
      <div class="paper-section paper-stats" style="margin-top: 4px;">
        <div>Total: <span id="paper-total">0</span> SOL</div>
        <div>PnL: <span id="paper-pnl">0</span></div>
      </div>
      
      <div class="paper-section" style="text-align: center; margin-top: 4px;">
        <div id="paper-pnl-percent" style="font-size: 20px; font-weight: bold;">0%</div>
        <div id="paper-mc-multiplier" style="font-size: 11px; color: #888;"></div>
      </div>

      <div class="paper-section">
        <label>Trade Amount (%)</label>
        <div class="paper-percent-btns" id="paper-percent-btns">
          <button class="paper-percent-btn" data-percent="25">25%</button>
          <button class="paper-percent-btn" data-percent="50">50%</button>
          <button class="paper-percent-btn" data-percent="75">75%</button>
          <button class="paper-percent-btn active" data-percent="100">100%</button>
        </div>
        <div class="paper-amount-row">
          <span>Buy: <span id="paper-buy-amount">0</span> SOL</span>
          <span>Sell: <span id="paper-sell-amount">0</span> SOL</span>
        </div>
        <div class="paper-trade-btns">
          <button id="paper-quick-buy" class="paper-trade-btn paper-trade-buy">🟢 BUY</button>
          <button id="paper-quick-sell" class="paper-trade-btn paper-trade-sell">🔴 SELL</button>
        </div>
      </div>

      <div class="paper-section">
        <label>Positions</label>
        <div id="paper-positions" class="paper-positions">No positions</div>
      </div>

      <div class="paper-section">
        <label>Trade History</label>
        <div id="paper-trades" class="paper-trades">No trades yet</div>
      </div>

      <div class="paper-section">
        <button id="paper-reset-btn" class="paper-btn paper-reset">Reset</button>
      </div>
      </div>
    `;

    document.body.appendChild(panel);

    // Initialize drag functionality
    initDrag();
    
    // Load saved position
    loadPanelPosition();

    bindUI();
    updateUI();
  }

  function loadPanelPosition() {
    chrome.storage.local.get(['axiom_panel_position'], (res) => {
      if (res.axiom_panel_position) {
        const panel = document.getElementById('axiom-paper-panel');
        if (panel) {
          panel.style.top = res.axiom_panel_position.top;
          panel.style.left = res.axiom_panel_position.left;
          panel.style.right = 'auto';
        }
      }
    });
  }

  function savePanelPosition(top, left) {
    chrome.storage.local.set({ axiom_panel_position: { top, left } });
  }

  function initDrag() {
    const panel = document.getElementById('axiom-paper-panel');
    const handle = document.getElementById('paper-drag-handle');
    const toggle = document.getElementById('paper-toggle');
    
    if (!panel || !handle) return;

    let isDragging = false;
    let startX, startY, startLeft, startTop;

    handle.addEventListener('mousedown', (e) => {
      // Don't drag if clicking the toggle
      if (e.target.closest('.paper-toggle-container')) return;
      
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      
      const rect = panel.getBoundingClientRect();
      startLeft = rect.left;
      startTop = rect.top;
      
      panel.style.right = 'auto';
      panel.style.left = startLeft + 'px';
      panel.style.top = startTop + 'px';
      
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      
      const newLeft = Math.max(0, Math.min(window.innerWidth - panel.offsetWidth, startLeft + dx));
      const newTop = Math.max(0, Math.min(window.innerHeight - panel.offsetHeight, startTop + dy));
      
      panel.style.left = newLeft + 'px';
      panel.style.top = newTop + 'px';
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        savePanelPosition(panel.style.top, panel.style.left);
      }
    });

    // Toggle switch for expand/collapse
    if (toggle) {
      toggle.onclick = (e) => {
        e.stopPropagation();
        toggle.classList.toggle('active');
        panel.classList.toggle('minimized');
      };
    }
  }

  function bindUI() {
    document.getElementById("paper-start-btn").onclick = () => {
      const val = parseFloat(
        document.getElementById("paper-start-input").value
      );
      if (isNaN(val) || val <= 0) return;

      state.startingBalance = val;
      state.balance = val;
      state.pnl = 0;
      state.active = true;
      state.positions = [];
      state.trades = [];
      saveState();
      updateUI();
      showNotification(`Paper trading started with ${val} SOL`, 'buy');
    };

    document.getElementById("paper-reset-btn").onclick = () => {
      resetState();
      showNotification('Paper trading reset', 'sell');
    };

    // Unified percentage buttons (used for both buy and sell)
    document.querySelectorAll('#paper-percent-btns .paper-percent-btn').forEach(btn => {
      btn.onclick = () => {
        document.querySelectorAll('#paper-percent-btns .paper-percent-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectedBuyPercent = parseInt(btn.dataset.percent);
        selectedSellPercent = parseInt(btn.dataset.percent);
        updateUI();
      };
    });

    // Quick buy button
    document.getElementById('paper-quick-buy').onclick = () => {
      if (!state.active) {
        showNotification('Start paper trading first!', 'error');
        return;
      }
      const marketCap = extractMarketCap();
      const tokenInfo = extractTokenInfo();
      if (marketCap <= 0) {
        showNotification('Cannot detect market cap!', 'error');
        return;
      }
      const solAmount = (state.balance * selectedBuyPercent) / 100;
      if (solAmount <= 0) {
        showNotification('No balance to buy!', 'error');
        return;
      }
      executePaperBuy(solAmount, tokenInfo, marketCap);
    };

    // Quick sell button
    document.getElementById('paper-quick-sell').onclick = () => {
      if (!state.active) {
        showNotification('Start paper trading first!', 'error');
        return;
      }
      const marketCap = extractMarketCap();
      const tokenInfo = extractTokenInfo();
      if (marketCap <= 0) {
        showNotification('Cannot detect market cap!', 'error');
        return;
      }
      const position = state.positions.find(p => p.address === tokenInfo.address);
      if (!position || position.investedSol <= 0) {
        showNotification('No position to sell!', 'error');
        return;
      }
      executePaperSell(selectedSellPercent, tokenInfo, marketCap);
    };
  }

  function updateUI() {
    const balanceEl = document.getElementById("paper-balance");
    const pnlEl = document.getElementById("paper-pnl");
    const pnlPercentEl = document.getElementById("paper-pnl-percent");
    const totalEl = document.getElementById("paper-total");
    const positionsValueEl = document.getElementById("paper-positions-value");
    const positionsEl = document.getElementById("paper-positions");
    const liveMcapEl = document.getElementById("paper-live-mcap");
    const liveTokenEl = document.getElementById("paper-live-token");

    if (!balanceEl || !pnlEl) return;

    const currentMarketCap = extractMarketCap();
    const tokenInfo = extractTokenInfo();

    // Calculate total position value based on current market cap
    let totalPositionValue = 0;
    state.positions.forEach(pos => {
      if (pos.address === tokenInfo.address && currentMarketCap > 0) {
        // For current token, use live market cap
        const mcapMultiplier = currentMarketCap / pos.entryMarketCap;
        totalPositionValue += pos.investedSol * mcapMultiplier;
      } else {
        // For other tokens, use invested amount (no live data)
        totalPositionValue += pos.investedSol;
      }
    });

    const totalValue = state.balance + totalPositionValue;
    const livePnl = totalValue - state.startingBalance;
    const livePnlPercent = state.startingBalance > 0 ? ((livePnl / state.startingBalance) * 100) : 0;

    balanceEl.innerText = state.balance.toFixed(4);
    if (positionsValueEl) positionsValueEl.innerText = totalPositionValue.toFixed(4);
    if (totalEl) totalEl.innerText = totalValue.toFixed(4);
    
    pnlEl.innerText = (livePnl >= 0 ? '+' : '') + livePnl.toFixed(4) + ' SOL';
    pnlEl.style.color = livePnl >= 0 ? "#00ff99" : "#ff4d4d";
    
    if (pnlPercentEl) {
      pnlPercentEl.innerText = (livePnlPercent >= 0 ? '+' : '') + livePnlPercent.toFixed(2) + '%';
      pnlPercentEl.style.color = livePnlPercent >= 0 ? "#00ff99" : "#ff4d4d";
    }

    // Update MC multiplier display for current position
    const mcMultiplierEl = document.getElementById('paper-mc-multiplier');
    if (mcMultiplierEl && currentMarketCap > 0) {
      const currentPos = state.positions.find(p => p.address === tokenInfo.address);
      if (currentPos) {
        const mult = currentMarketCap / currentPos.entryMarketCap;
        const multColor = mult >= 1 ? '#00ff99' : '#ff4d4d';
        mcMultiplierEl.innerHTML = `MC: ${formatMarketCap(currentPos.entryMarketCap)} → ${formatMarketCap(currentMarketCap)} = <span style="color: ${multColor}">${mult.toFixed(2)}x</span>`;
      } else {
        mcMultiplierEl.innerText = '';
      }
    }

    // Update positions with live PnL based on MC ratio
    // Formula: PnL% = (currentMC / entryMC - 1) * 100
    // Example: Entry $15K, Current $30K = (30K/15K - 1) * 100 = +100%
    // Example: Entry $15K, Current $7.5K = (7.5K/15K - 1) * 100 = -50%
    if (positionsEl) {
      if (state.positions.length === 0) {
        positionsEl.innerHTML = '<div style="color: #666;">No positions</div>';
      } else {
        positionsEl.innerHTML = state.positions.map(p => {
          let currentValue = p.investedSol;
          let pnlPct = 0;
          let currentMC = p.entryMarketCap;
          let mcMultiplier = 1;
          
          if (p.address === tokenInfo.address && currentMarketCap > 0) {
            mcMultiplier = currentMarketCap / p.entryMarketCap;
            currentValue = p.investedSol * mcMultiplier;
            // PnL% = (currentMC / entryMC - 1) * 100
            pnlPct = (mcMultiplier - 1) * 100;
            currentMC = currentMarketCap;
          }
          
          const pnlColor = pnlPct >= 0 ? '#00ff99' : '#ff4d4d';
          const pnlSign = pnlPct >= 0 ? '+' : '';
          const multiplierText = mcMultiplier >= 1 
            ? `${mcMultiplier.toFixed(2)}x` 
            : `${mcMultiplier.toFixed(2)}x`;
          
          return `
            <div class="paper-position-item">
              <span>${p.symbol}</span>
              <span style="color: ${pnlColor}; font-weight: bold;">${pnlSign}${pnlPct.toFixed(1)}%</span>
            </div>
            <div style="font-size: 10px; color: #888; margin-bottom: 2px;">
              Entry: <span class="paper-mc-badge paper-mc-entry">${formatMarketCap(p.entryMarketCap)}</span>
              ${currentMarketCap > 0 && p.address === tokenInfo.address 
                ? `→ <span style="color: ${pnlColor};">${formatMarketCap(currentMC)}</span> <span style="color: ${pnlColor};">(${multiplierText})</span>` 
                : ''}
            </div>
            <div style="font-size: 10px; color: #666; margin-bottom: 6px;">
              Value: ${p.investedSol.toFixed(4)} → <span style="color: ${pnlColor};">${currentValue.toFixed(4)}</span> SOL
            </div>
          `;
        }).join('');
      }
    }

    // Update trade history
    const tradesEl = document.getElementById('paper-trades');
    if (tradesEl) {
      if (state.trades.length === 0) {
        tradesEl.innerHTML = '<div style="color: #666;">No trades yet</div>';
      } else {
        // Show trades in reverse order (newest first)
        const recentTrades = [...state.trades].reverse().slice(0, 20);
        tradesEl.innerHTML = recentTrades.map(t => {
          const time = new Date(t.time).toLocaleTimeString();
          const isBuy = t.type === 'BUY';
          
          if (isBuy) {
            return `
              <div class="paper-trade-item">
                <span class="paper-trade-buy-label">BUY</span> ${t.symbol}
                <span class="paper-mc-badge paper-mc-entry">${formatMarketCap(t.marketCap)}</span>
                <div class="paper-trade-details">
                  ${t.solAmount.toFixed(4)} SOL • ${time}
                </div>
              </div>
            `;
          } else {
            return `
              <div class="paper-trade-item">
                <span class="paper-trade-sell-label">SELL</span> ${t.symbol}
                <span class="paper-mc-badge paper-mc-exit">${formatMarketCap(t.marketCap)}</span>
                <span style="color: ${parseFloat(t.pnlPercent) >= 0 ? '#00ff99' : '#ff4d4d'};">
                  (${parseFloat(t.pnlPercent) >= 0 ? '+' : ''}${t.pnlPercent}%)
                </span>
                <div class="paper-trade-details">
                  ${t.proceeds.toFixed(4)} SOL • ${time}
                </div>
              </div>
            `;
          }
        }).join('');
      }
    }

    // Update live market cap
    if (liveMcapEl) {
      liveMcapEl.innerText = currentMarketCap > 0 ? formatMarketCap(currentMarketCap) : '--';
      liveMcapEl.style.color = currentMarketCap > 0 ? '#00ffd1' : '#ff4d4d';
    }

    // Update MC status
    const mcStatusEl = document.getElementById('paper-mc-status');
    if (mcStatusEl) {
      const manualMC = document.getElementById('paper-manual-mc');
      if (manualMC && manualMC.value && parseMarketCapValue(manualMC.value) > 0) {
        mcStatusEl.innerText = '(manual)';
        mcStatusEl.style.color = '#ffaa00';
      } else if (currentMarketCap > 0) {
        mcStatusEl.innerText = '(auto)';
        mcStatusEl.style.color = '#00ff99';
      } else {
        mcStatusEl.innerText = '(not found)';
        mcStatusEl.style.color = '#ff4d4d';
      }
    }

    if (liveTokenEl) {
      liveTokenEl.innerText = tokenInfo.symbol || '--';
    }

    // Update token address display
    const liveAddressEl = document.getElementById('paper-live-address');
    if (liveAddressEl) {
      liveAddressEl.innerText = tokenInfo.address || '--';
      liveAddressEl.onclick = () => {
        if (tokenInfo.address) {
          navigator.clipboard.writeText(tokenInfo.address);
          showNotification('Address copied!', 'buy');
        }
      };
    }

    // Update header token display
    const headerTokenEl = document.getElementById('paper-header-token');
    if (headerTokenEl) {
      const displayText = tokenInfo.symbol || (tokenInfo.address ? tokenInfo.address.slice(0, 6) + '...' : '') || 'ARKEN';
      headerTokenEl.innerText = displayText;
    }

    // Update buy amount display
    const buyAmountEl = document.getElementById('paper-buy-amount');
    if (buyAmountEl) {
      const buyAmount = (state.balance * selectedBuyPercent) / 100;
      buyAmountEl.innerText = buyAmount.toFixed(4);
    }

    // Update sell amount display (show current value, not just invested)
    const sellAmountEl = document.getElementById('paper-sell-amount');
    if (sellAmountEl) {
      const position = state.positions.find(p => p.address === tokenInfo.address);
      if (position && currentMarketCap > 0) {
        const mcapMultiplier = currentMarketCap / position.entryMarketCap;
        const currentValue = position.investedSol * mcapMultiplier;
        const sellValue = (currentValue * selectedSellPercent) / 100;
        sellAmountEl.innerText = sellValue.toFixed(4) + ' SOL';
      } else if (position) {
        const sellValue = (position.investedSol * selectedSellPercent) / 100;
        sellAmountEl.innerText = sellValue.toFixed(4) + ' SOL';
      } else {
        sellAmountEl.innerText = '0';
      }
    }

    // Update button states
    const buyBtn = document.getElementById('paper-quick-buy');
    const sellBtn = document.getElementById('paper-quick-sell');
    if (buyBtn) buyBtn.disabled = !state.active || state.balance <= 0;
    if (sellBtn) {
      const position = state.positions.find(p => p.address === tokenInfo.address);
      sellBtn.disabled = !state.active || !position || position.investedSol <= 0;
    }
  }

  // Throttle function to limit how often a function can be called
  let lastUpdateTime = 0;
  const UPDATE_THROTTLE = 200; // Minimum ms between updates

  function throttledUpdateUI() {
    const now = Date.now();
    if (now - lastUpdateTime >= UPDATE_THROTTLE) {
      lastUpdateTime = now;
      updateUI();
    }
  }

  function init() {
    createUI();
    loadState();
    hookTradingButtons();

    // Fast update interval for live MC tracking (250ms)
    setInterval(() => {
      updateUI();
    }, 250);

    // Slower interval for re-hooking buttons (1.5s)
    setInterval(() => {
      hookTradingButtons();
    }, 1500);

    // Listen for URL changes (popstate for back/forward navigation)
    window.addEventListener('popstate', () => {
      clearMCCache();
      updateUI();
    });

    // Override pushState and replaceState to detect SPA navigation
    const originalPushState = history.pushState;
    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      clearMCCache();
      setTimeout(updateUI, 100);
    };

    const originalReplaceState = history.replaceState;
    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      clearMCCache();
      setTimeout(updateUI, 100);
    };
  }

  // Wait for DOM to be ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Observe DOM changes to update UI immediately when MC changes
  const observer = new MutationObserver((mutations) => {
    // Check if any mutation might be MC-related
    let shouldUpdate = false;
    for (const mutation of mutations) {
      if (mutation.type === 'characterData' || 
          (mutation.type === 'childList' && mutation.addedNodes.length > 0)) {
        shouldUpdate = true;
        break;
      }
    }
    if (shouldUpdate) {
      throttledUpdateUI();
    }
    createUI();
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
    characterDataOldValue: false
  });
})();
